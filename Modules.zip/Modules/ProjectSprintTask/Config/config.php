<?php

return [
    'name' => 'ProjectSprintTask'
];
