<?php

return [
    'name' => 'EmailGroup'
];
