<?php

return [
    'name' => 'DefectAttachment'
];
