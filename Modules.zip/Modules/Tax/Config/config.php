<?php

return [
    'name' => 'Tax'
];
