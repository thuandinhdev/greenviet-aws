<?php

return [
    'name' => 'Team'
];
