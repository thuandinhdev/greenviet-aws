<?php

return [
    'name' => 'Projects'
];
