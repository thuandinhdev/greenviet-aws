<?php

return [
    'name' => 'Meeting'
];
