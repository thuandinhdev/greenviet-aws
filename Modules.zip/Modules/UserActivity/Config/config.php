<?php

return [
    'name' => 'UserActivity'
];
