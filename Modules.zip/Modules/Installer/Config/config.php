<?php

return [
    'name' => 'Installer'
];
