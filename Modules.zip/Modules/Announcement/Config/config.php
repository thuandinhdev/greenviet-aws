<?php

return [
    'name' => 'Announcement'
];
