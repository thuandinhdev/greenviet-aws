<?php

return [
    'name' => 'IncidentComment'
];
