<?php

return [
    'name' => 'KnowledgeBaseArticle'
];
