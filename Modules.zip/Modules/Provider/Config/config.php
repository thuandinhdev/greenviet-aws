<?php

return [
    'name' => 'Provider'
];
