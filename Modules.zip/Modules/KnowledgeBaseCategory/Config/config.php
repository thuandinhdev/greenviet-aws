<?php

return [
    'name' => 'KnowledgeBaseCategory'
];
