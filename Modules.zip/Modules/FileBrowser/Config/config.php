<?php

return [
    'name' => 'FileBrowser'
];
