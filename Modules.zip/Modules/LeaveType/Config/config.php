<?php

return [
    'name' => 'LeaveType'
];
