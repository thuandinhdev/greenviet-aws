<?php

return [
    'name' => 'Appointments'
];
