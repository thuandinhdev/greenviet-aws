<?php

return [
    'name' => 'EmailTemplate'
];
