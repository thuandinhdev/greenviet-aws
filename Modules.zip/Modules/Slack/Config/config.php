<?php

return [
    'name' => 'Slack'
];
