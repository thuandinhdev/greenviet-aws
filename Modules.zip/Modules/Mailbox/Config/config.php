<?php

return [
    'name' => 'Mailbox'
];
