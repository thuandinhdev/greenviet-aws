<?php

return [
    'name' => 'Incident'
];
